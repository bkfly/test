%% Extreme learning machine

%% Clear environment variables
clear all
clc
warning off

%% Import data

% Training data
%P_train  -  Input Matrix of Training Set  
%T_train  -  Output labels of Training Set 
% Test data
%P_test  -   Input Matrix of Test Set  
%T_test  -   Output labels of Test Set  


%% ELM Training
tic
[IW,B,LW,TF,TYPE] = elmtrain(P_train,T_train,100,'sig',1);

%% Simulation test
T_sim_1 = elmpredict(P_train,IW,B,LW,TF,TYPE);
T_sim_2 = elmpredict(P_test,IW,B,LW,TF,TYPE);

toc
%% Comparison of results
result_1 = [T_train' T_sim_1'];
result_2 = [T_test' T_sim_2'];
% The accuracy of training set
k1 = length(find(T_train == T_sim_1));
n1 = length(T_train);
Accuracy_1 = k1 / n1 * 100;
disp(['Accuracy (training set) = ' num2str(Accuracy_1) '%(' num2str(k1) '/' num2str(n1) ')'])
% The accuracy of test set
k2 = length(find(T_test == T_sim_2));
n2 = length(T_test);
Accuracy_2 = k2 / n2 * 100;
disp(['Accuracy (test set) = ' num2str(Accuracy_2) '%(' num2str(k2) '/' num2str(n2) ')'])
